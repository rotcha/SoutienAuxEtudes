"use strict";
function __export(m) {
    for (var p in m) if (!exports.hasOwnProperty(p)) exports[p] = m[p];
}
/**
 * Created by Jenny on 2017-01-03.
 */
__export(require("./about.component"));
__export(require("./about.routes"));
//# sourceMappingURL=index.js.map