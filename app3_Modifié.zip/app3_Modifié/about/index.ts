/**
 * Created by Jenny on 2017-01-03.
 */
export * from './about.component';
export *from './about.routes';