"use strict";
var index_1 = require("./index");
exports.AboutRoutes = [
    {
        path: 'about',
        component: index_1.AboutComponent
    }
];
//# sourceMappingURL=about.routes.js.map