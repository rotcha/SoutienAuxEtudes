/**
 * Created by Jenny on 2017-01-03.
 */
import {Component} from
    '@angular/core';
@Component({
    moduleId: module.id,
    selector:'sd-about',
    templateUrl:'./about.component.html',
    // styleUrls:['./about.component.css']
})
export class AboutComponent{};
