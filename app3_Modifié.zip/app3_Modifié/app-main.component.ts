/**
 * Created by louly on 2017-01-03.
 */
import {Component} from '@angular/core';
import {PolyHackInfo} from './polyhackInfo.component';
import {AboutComponent} from './about.component';

@Component({
    selector:'polyhack',
    templateUrl:'app3_Modifié/app-main-template.html'
})
export class PolyHackApp{}